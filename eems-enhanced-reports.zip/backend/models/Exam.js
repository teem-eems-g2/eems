

// Exam model placeholder
module.exports = class Exam {
  constructor(title, duration) {
    this.title = title;
    this.duration = duration;
  }
};
