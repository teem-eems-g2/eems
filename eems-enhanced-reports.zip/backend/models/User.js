

// User model placeholder
module.exports = class User {
  constructor(email, role) {
    this.email = email;
    this.role = role;
  }
};

